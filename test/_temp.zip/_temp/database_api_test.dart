//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for DatabaseApi
void main() {
  // final instance = DatabaseApi();

  group('tests for DatabaseApi', () {
    // Your GET endpoint
    //
    // This is going to export your current database.
    //
    //Future<ExportedDatabase> databaseExport() async
    test('test databaseExport', () async {
      // TODO
    });

    // /database/import [POST]
    //
    // This is going to take in a database, and merge it with the current database. This will revert your database back to it original form if this request fails.
    //
    //Future databaseImport({ ExportedDatabase exportedDatabase }) async
    test('test databaseImport', () async {
      // TODO
    });

  });
}
