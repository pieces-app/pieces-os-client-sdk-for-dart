//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for MetricsApi
void main() {
  // final instance = MetricsApi();

  group('tests for MetricsApi', () {
    // /metrics/formats [GET]
    //
    // This is going to get a snapshot of our FormatsMetrics
    //
    //Future<FormatsMetrics> getMetricsFormats() async
    test('test getMetricsFormats', () async {
      // TODO
    });

    // /metrics/formats/ordered [GET]
    //
    // This will return a list of code formats in desc order from most to least formats uploaded.
    //
    //Future<OrderedMetrics> metricsFormatsOrdered() async
    test('test metricsFormatsOrdered', () async {
      // TODO
    });

  });
}
