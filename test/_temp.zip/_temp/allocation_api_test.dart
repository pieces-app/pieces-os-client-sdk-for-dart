//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for AllocationApi
void main() {
  // final instance = AllocationApi();

  group('tests for AllocationApi', () {
    // /allocation/{allocation} [GET]
    //
    // This will get a snapshot of a specific allocation.
    //
    //Future<AllocationCloud> allocationSnapshot(String allocation) async
    test('test allocationSnapshot', () async {
      // TODO
    });

    // /allocation/update [POST]
    //
    // This will update a specific allocation.
    //
    //Future<AllocationCloud> allocationUpdate({ AllocationCloud allocationCloud }) async
    test('test allocationUpdate', () async {
      // TODO
    });

  });
}
