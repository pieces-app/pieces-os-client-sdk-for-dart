//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for ShareApi
void main() {
  // final instance = ShareApi();

  group('tests for ShareApi', () {
    // /share/{share}
    //
    // Get the snapshot of a specific share.
    //
    //Future<Share> shareSnapshot(String share, { bool transferables }) async
    test('test shareSnapshot', () async {
      // TODO
    });

    // /share/update [POST]
    //
    // This endpoint will accept a Share that the user wants to update, and will return a full Share that was updated!
    //
    //Future<Share> shareUpdate({ bool transferables, Share share }) async
    test('test shareUpdate', () async {
      // TODO
    });

  });
}
