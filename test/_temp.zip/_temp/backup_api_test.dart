//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for BackupApi
void main() {
  // final instance = BackupApi();

  group('tests for BackupApi', () {
    // /backup [POST]
    //
    // 
    //
    //Future backup({ Assets assets }) async
    test('test backup', () async {
      // TODO
    });

    // /backup/asset [POST]
    //
    //Future backupAsset({ Asset asset }) async
    test('test backupAsset', () async {
      // TODO
    });

  });
}
