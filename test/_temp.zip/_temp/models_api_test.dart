//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for ModelsApi
void main() {
  // final instance = ModelsApi();

  group('tests for ModelsApi', () {
    // /models/create [POST]
    //
    // 
    //
    //Future<Model> modelsCreateNewModel({ SeededModel seededModel }) async
    test('test modelsCreateNewModel', () async {
      // TODO
    });

    // /models/{model}/delete [POST]
    //
    // 
    //
    //Future modelsDeleteSpecificModel(String model) async
    test('test modelsDeleteSpecificModel', () async {
      // TODO
    });

    // /models [GET]
    //
    // This will get a snapshot of all of your models.
    //
    //Future<Models> modelsSnapshot() async
    test('test modelsSnapshot', () async {
      // TODO
    });

  });
}
