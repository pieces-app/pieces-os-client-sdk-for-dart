//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for LinkifyApi
void main() {
  // final instance = LinkifyApi();

  group('tests for LinkifyApi', () {
    // /linkify [POST]
    //
    // 
    //
    //Future<Shares> linkify({ Linkify linkify }) async
    test('test linkify', () async {
      // TODO
    });

    // /linkify/multiple [POST]
    //
    // - assumption that you have already backed up the asset's that you are sending to this endpoint.(b/c the assets are ids.)
    //
    //Future<Shares> linkifyMultiple({ LinkifyMultiple linkifyMultiple }) async
    test('test linkifyMultiple', () async {
      // TODO
    });

    // [POST} /linkify/{share}/revoke
    //
    // This will revoke a link.
    //
    //Future<String> linkifyShareRevoke(String share) async
    test('test linkifyShareRevoke', () async {
      // TODO
    });

  });
}
