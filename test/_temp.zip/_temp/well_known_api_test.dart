//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for WellKnownApi
void main() {
  // final instance = WellKnownApi();

  group('tests for WellKnownApi', () {
    // /.well-known/health [GET]
    //
    // This will get the health of the server.
    //
    //Future<String> getWellKnownHealth() async
    test('test getWellKnownHealth', () async {
      // TODO
    });

    // /.well-known/version [Get]
    //
    // This will get the version of the server. This will return a string of current version.
    //
    //Future<String> getWellKnownVersion() async
    test('test getWellKnownVersion', () async {
      // TODO
    });

  });
}
