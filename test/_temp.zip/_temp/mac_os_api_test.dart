//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for MacOSApi
void main() {
  // final instance = MacOSApi();

  group('tests for MacOSApi', () {
    // /macos/assets/create [Post]
    //
    // Exposes an endpoint for the MacOS Services plugin to send over MacOS Specific Data
    //
    //Future<Asset> assetsCreateNewAssetFromMacos({ SeededMacOSAsset seededMacOSAsset }) async
    test('test assetsCreateNewAssetFromMacos', () async {
      // TODO
    });

  });
}
