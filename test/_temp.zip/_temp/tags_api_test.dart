//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for TagsApi
void main() {
  // final instance = TagsApi();

  group('tests for TagsApi', () {
    // /tags/create [POST]
    //
    // This will create a new tag.
    //
    //Future<Tag> tagsCreateNewTag({ bool transferables, SeededTag seededTag }) async
    test('test tagsCreateNewTag', () async {
      // TODO
    });

    // /tags/{tag}/delete [POST]
    //
    // This will delete a specific tag.
    //
    //Future tagsDeleteSpecificTag(String tag) async
    test('test tagsDeleteSpecificTag', () async {
      // TODO
    });

    // /tags [GET]
    //
    // This will get a snapshot of all of your tags.
    //
    //Future<Tags> tagsSnapshot({ bool transferables }) async
    test('test tagsSnapshot', () async {
      // TODO
    });

  });
}
