//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for WebsitesApi
void main() {
  // final instance = WebsitesApi();

  group('tests for WebsitesApi', () {
    // /websites/create [POST]
    //
    // This will create a website and attach it to a specific asset.
    //
    //Future<Website> websitesCreateNewWebsite({ bool transferables, SeededWebsite seededWebsite }) async
    test('test websitesCreateNewWebsite', () async {
      // TODO
    });

    // /websites/{website}/delete [POST]
    //
    // This will delete a specific website!
    //
    //Future websitesDeleteSpecificWebsite(String website) async
    test('test websitesDeleteSpecificWebsite', () async {
      // TODO
    });

    // /websites [GET]
    //
    // This will get a snapshot of all your websites.
    //
    //Future<Websites> websitesSnapshot({ bool transferables }) async
    test('test websitesSnapshot', () async {
      // TODO
    });

  });
}
