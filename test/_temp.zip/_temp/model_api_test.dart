//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for ModelApi
void main() {
  // final instance = ModelApi();

  group('tests for ModelApi', () {
    // /model/update [POST]
    //
    //Future<Model> modelUpdate({ Model model }) async
    test('test modelUpdate', () async {
      // TODO
    });

    // /model/{model} [GET]
    //
    // 
    //
    //Future<Model> modelsSpecificModelSnapshot(String model) async
    test('test modelsSpecificModelSnapshot', () async {
      // TODO
    });

  });
}
