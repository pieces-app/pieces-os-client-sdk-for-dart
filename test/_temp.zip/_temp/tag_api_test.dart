//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for TagApi
void main() {
  // final instance = TagApi();

  group('tests for TagApi', () {
    // /tag/update [POST]
    //
    // This will update a specific tag.
    //
    //Future<Tag> tagUpdate({ bool transferables, Tag tag }) async
    test('test tagUpdate', () async {
      // TODO
    });

    // /tag/{tag} [GET]
    //
    // This will get a specific tag.
    //
    //Future<Tag> tagsSpecificTagSnapshot(String tag, { bool transferables }) async
    test('test tagsSpecificTagSnapshot', () async {
      // TODO
    });

  });
}
