//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for ApplicationApi
void main() {
  // final instance = ApplicationApi();

  group('tests for ApplicationApi', () {
    // /application/update [GET]
    //
    // This is an endpoint for updating an application.
    //
    //Future<Application> applicationUpdate({ Application application }) async
    test('test applicationUpdate', () async {
      // TODO
    });

  });
}
