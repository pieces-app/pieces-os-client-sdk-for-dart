//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for SensitivesApi
void main() {
  // final instance = SensitivesApi();

  group('tests for SensitivesApi', () {
    // /sensitives/create [POST]
    //
    // This will create a new sensitive model.
    //
    //Future<Sensitive> sensitivesCreateNewSensitive({ SeededSensitive seededSensitive }) async
    test('test sensitivesCreateNewSensitive', () async {
      // TODO
    });

    // /sensitives/{sensitive}/delete [POST]
    //
    // This will delete a sensitive based on the sensative uuid.
    //
    //Future sensitivesDeleteSensitive(String sensitive) async
    test('test sensitivesDeleteSensitive', () async {
      // TODO
    });

    // /sensitives [GET]
    //
    // This will get a snapshot of all of the sensitives.
    //
    //Future<Sensitives> sensitivesSnapshot() async
    test('test sensitivesSnapshot', () async {
      // TODO
    });

  });
}
