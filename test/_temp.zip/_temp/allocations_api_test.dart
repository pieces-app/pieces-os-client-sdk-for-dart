//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for AllocationsApi
void main() {
  // final instance = AllocationsApi();

  group('tests for AllocationsApi', () {
    // /allocations/connect [POST]
    //
    // This will attempt to connect to a specific users cloud.(Required that the current user is logged in.)
    //
    //Future<AllocationCloud> allocationsConnectNewCloud({ UserProfile userProfile }) async
    test('test allocationsConnectNewCloud', () async {
      // TODO
    });

    // /allocations/create [POST]
    //
    // This is unimplemented locally. This will create an allocation. ONLY used within the cloud.
    //
    //Future<AllocationCloud> allocationsCreateNewAllocation({ AllocationCloud allocationCloud }) async
    test('test allocationsCreateNewAllocation', () async {
      // TODO
    });

    // /allocations/delete [POST]
    //
    // This is unimplemented locally. This will delete an allocation. ONLY used within the cloud.
    //
    //Future<String> allocationsDeleteAllocation({ AllocationCloud allocationCloud }) async
    test('test allocationsDeleteAllocation', () async {
      // TODO
    });

    // /allocations/disconnect [POST]
    //
    // This will attempt to disconnect to a specific users cloud.
    //
    //Future<String> allocationsDisconnectCloud({ AllocationCloud allocationCloud }) async
    test('test allocationsDisconnectCloud', () async {
      // TODO
    });

    // /allocations/reconnect [POST]
    //
    // This will attempt to reconnect to a users cloud. This will ensure that we are connected to a users cloud and will ensure that all the data associated with a user's cloud is up-to-date.
    //
    //Future<AllocationCloud> allocationsReconnectCloud({ AllocationCloud allocationCloud }) async
    test('test allocationsReconnectCloud', () async {
      // TODO
    });

    // /allocations [GET]
    //
    // This is going to get a snapshot of all of the connected allocations.
    //
    //Future<Allocations> allocationsSnapshot() async
    test('test allocationsSnapshot', () async {
      // TODO
    });

  });
}
