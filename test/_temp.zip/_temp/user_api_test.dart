//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for UserApi
void main() {
  // final instance = UserApi();

  group('tests for UserApi', () {
    // /user/clear
    //
    // An endpoint to clear the current user. 
    //
    //Future clearUser() async
    test('test clearUser', () async {
      // TODO
    });

    // /user/select [POST]
    //
    // This will select the current user.
    //
    //Future<UserProfile> selectUser({ Auth0User auth0User }) async
    test('test selectUser', () async {
      // TODO
    });

    // /user/stream [GET]
    //
    // This will stream in the current user, not quiet sure yet how we want to do this.
    //
    //Future<UserProfile> streamUser() async
    test('test streamUser', () async {
      // TODO
    });

    // /user/update [POST]
    //
    // This will update a specific user in the database.
    //
    //Future<UserProfile> updateUser({ UserProfile userProfile }) async
    test('test updateUser', () async {
      // TODO
    });

    // /user [GET]
    //
    // This will return a snapshot of the current user. This will return our ReturnUserProfile and the user on that object is just a UserProfile and can potentially be null.
    //
    //Future<ReturnedUserProfile> userSnapshot() async
    test('test userSnapshot', () async {
      // TODO
    });

    // /user/update/vanity [POST]
    //
    // This is a local route to update your vanityname. ie mark.pieces.cloud, where \"mark\" is the vanityname.
    //
    //Future<UserProfile> userUpdateVanity({ UserProfile userProfile }) async
    test('test userUpdateVanity', () async {
      // TODO
    });

  });
}
