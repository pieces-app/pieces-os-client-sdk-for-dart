//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import '../../lib/api.dart';
<!--pubLibrary-->
import 'package:test/test.dart';


/// tests for WebsiteApi
void main() {
  // final instance = WebsiteApi();

  group('tests for WebsiteApi', () {
    // /website/update [POST]
    //
    // This will update a specific website.
    //
    //Future<Website> websiteUpdate({ bool transferables, Website website }) async
    test('test websiteUpdate', () async {
      // TODO
    });

    // /website/{website} [GET]
    //
    // This will get a snapshot of a single website.
    //
    //Future<Website> websitesSpecificWebsiteSnapshot(String website, { bool transferables }) async
    test('test websitesSpecificWebsiteSnapshot', () async {
      // TODO
    });

  });
}
