# core_openapi.api.ApplicationsApi

## Load the API package
```dart
import '../lib/api.dart';
```

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**applicationsRegister**](ApplicationsApi.md#applicationsregister) | **POST** /applications/register | /applications/register [POST]
[**applicationsSessionClose**](ApplicationsApi.md#applicationssessionclose) | **POST** /applications/session/close | /applications/session/close [POST]
[**applicationsSessionOpen**](ApplicationsApi.md#applicationssessionopen) | **POST** /applications/session/open | /applications/session/open [POST]
[**applicationsSessionSnapshot**](ApplicationsApi.md#applicationssessionsnapshot) | **GET** /applications/sessions/{session} | /applications/sessions/{session} [GET]
[**applicationsSnapshot**](ApplicationsApi.md#applicationssnapshot) | **GET** /applications | /applications [GET]
[**applicationsSpecificApplicationSnapshot**](ApplicationsApi.md#applicationsspecificapplicationsnapshot) | **GET** /applications/{application} | /applications/{application} [GET]
[**applicationsUsageEngagementInteraction**](ApplicationsApi.md#applicationsusageengagementinteraction) | **POST** /applications/usage/engagement/interaction | /applications/usage/engagement/interaction [POST] Scoped to Apps
[**applicationsUsageEngagementKeyboard**](ApplicationsApi.md#applicationsusageengagementkeyboard) | **POST** /applications/usage/engagement/keyboard | /applications/usage/engagement/keyboard [POST] Scoped to Apps
[**applicationsUsageInstallation**](ApplicationsApi.md#applicationsusageinstallation) | **POST** /applications/usage/installation | /applications/usage/installation [POST]
[**postApplicationsUsageUpdated**](ApplicationsApi.md#postapplicationsusageupdated) | **POST** /applications/usage/updated | /applications/usage/updated [POST]


# **applicationsRegister**
> Application applicationsRegister(application)

/applications/register [POST]

This will register a connected applicaiton.

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final application = Application(); // Application | This will accept a application.

try {
    final result = api_instance.applicationsRegister(application);
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsRegister: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application** | [**Application**](Application.md)| This will accept a application. | [optional] 

### Return type

[**Application**](Application.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsSessionClose**
> Session applicationsSessionClose(body)

/applications/session/close [POST]

This will close your opened session! Going to want to accept a session uuid here.

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final body = String(); // String | This will accept a required session uuid.

try {
    final result = api_instance.applicationsSessionClose(body);
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsSessionClose: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | **String**| This will accept a required session uuid. | [optional] 

### Return type

[**Session**](Session.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsSessionOpen**
> Session applicationsSessionOpen()

/applications/session/open [POST]

This will open a new session. A session is when someone is using the pieces application.

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();

try {
    final result = api_instance.applicationsSessionOpen();
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsSessionOpen: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Session**](Session.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsSessionSnapshot**
> Session applicationsSessionSnapshot(session)

/applications/sessions/{session} [GET]

This is an endpoint to get a snapshot of a specific session.

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final session = session_example; // String | This is a uuid that points to a session.

try {
    final result = api_instance.applicationsSessionSnapshot(session);
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsSessionSnapshot: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **session** | **String**| This is a uuid that points to a session. | 

### Return type

[**Session**](Session.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsSnapshot**
> Applications applicationsSnapshot()

/applications [GET]



### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();

try {
    final result = api_instance.applicationsSnapshot();
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsSnapshot: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Applications**](Applications.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsSpecificApplicationSnapshot**
> Application applicationsSpecificApplicationSnapshot(application)

/applications/{application} [GET]

This will retrieve snapshot of a single application.

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final application = application_example; // String | This is a uuid that represents an application

try {
    final result = api_instance.applicationsSpecificApplicationSnapshot(application);
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsSpecificApplicationSnapshot: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application** | **String**| This is a uuid that represents an application | 

### Return type

[**Application**](Application.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsUsageEngagementInteraction**
> TrackedInteractionEvent applicationsUsageEngagementInteraction(seededTrackedInteractionEvent)

/applications/usage/engagement/interaction [POST] Scoped to Apps

This is an analytics endpoint that will enable us to know when a user engages something via an interaction(ie click/tap).

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final seededTrackedInteractionEvent = SeededTrackedInteractionEvent(); // SeededTrackedInteractionEvent | 

try {
    final result = api_instance.applicationsUsageEngagementInteraction(seededTrackedInteractionEvent);
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsUsageEngagementInteraction: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **seededTrackedInteractionEvent** | [**SeededTrackedInteractionEvent**](SeededTrackedInteractionEvent.md)|  | [optional] 

### Return type

[**TrackedInteractionEvent**](TrackedInteractionEvent.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsUsageEngagementKeyboard**
> TrackedKeyboardEvent applicationsUsageEngagementKeyboard(seededTrackedKeyboardEvent)

/applications/usage/engagement/keyboard [POST] Scoped to Apps

This is an analytics endpoint that will enable us to know when a user uses a keyboard short cut for any sort of engagement.

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final seededTrackedKeyboardEvent = SeededTrackedKeyboardEvent(); // SeededTrackedKeyboardEvent | 

try {
    final result = api_instance.applicationsUsageEngagementKeyboard(seededTrackedKeyboardEvent);
    print(result);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsUsageEngagementKeyboard: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **seededTrackedKeyboardEvent** | [**SeededTrackedKeyboardEvent**](SeededTrackedKeyboardEvent.md)|  | [optional] 

### Return type

[**TrackedKeyboardEvent**](TrackedKeyboardEvent.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **applicationsUsageInstallation**
> applicationsUsageInstallation(trackedApplicationInstall)

/applications/usage/installation [POST]

This is an analytics endpoint that will enable us to know when a user has installed a version of Pieces

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final trackedApplicationInstall = TrackedApplicationInstall(); // TrackedApplicationInstall | 

try {
    api_instance.applicationsUsageInstallation(trackedApplicationInstall);
} catch (e) {
    print('Exception when calling ApplicationsApi->applicationsUsageInstallation: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackedApplicationInstall** | [**TrackedApplicationInstall**](TrackedApplicationInstall.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **postApplicationsUsageUpdated**
> postApplicationsUsageUpdated(trackedApplicationUpdate)

/applications/usage/updated [POST]

This is an endpoint to determine when an application has been updated 

### Example
```dart
import '../lib/api.dart';

final api_instance = ApplicationsApi();
final trackedApplicationUpdate = TrackedApplicationUpdate(); // TrackedApplicationUpdate | Sending over the previous application version, the current version, and the user.

try {
    api_instance.postApplicationsUsageUpdated(trackedApplicationUpdate);
} catch (e) {
    print('Exception when calling ApplicationsApi->postApplicationsUsageUpdated: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackedApplicationUpdate** | [**TrackedApplicationUpdate**](TrackedApplicationUpdate.md)| Sending over the previous application version, the current version, and the user. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

