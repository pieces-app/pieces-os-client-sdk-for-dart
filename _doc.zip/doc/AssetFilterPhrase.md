# core_openapi.model.AssetFilterPhrase

## Load the model package
```dart
import '../lib/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**schema** | [**EmbeddedModelSchema**](EmbeddedModelSchema.md) |  | [optional] 
**value** | **String** |  | [optional] 
**annotation** | **bool** |  | [optional] 
**title** | **bool** |  | [optional] 
**content** | **bool** |  | [optional] 
**options** | [**AssetFilterPhraseOptions**](AssetFilterPhraseOptions.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


