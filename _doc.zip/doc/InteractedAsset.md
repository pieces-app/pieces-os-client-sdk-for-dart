# core_openapi.model.InteractedAsset

## Load the model package
```dart
import '../lib/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**asset** | **String** | A uuid model. 36 Characters (4 Dashes, 32 Numbers/Letters)  | [optional] 
**interactions** | [**InteractedAssetInteractions**](InteractedAssetInteractions.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


