# core_openapi.model.TagsExistsInput

## Load the model package
```dart
import '../lib/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**schema** | [**EmbeddedModelSchema**](EmbeddedModelSchema.md) |  | [optional] 
**tag** | **String** | This is the tag that you want to see if this exists in the database. this is NOT a uuid. this is the tag value. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


